﻿namespace BlazorShared.Models;

public class DeleteCatalogItemResponse
{
    public string Status { get; set; } = "Deleted";
}
